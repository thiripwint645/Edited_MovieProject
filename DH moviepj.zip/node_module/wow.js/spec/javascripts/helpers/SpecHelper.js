(function() {
  beforeEach(function() {});

}).call(this);
