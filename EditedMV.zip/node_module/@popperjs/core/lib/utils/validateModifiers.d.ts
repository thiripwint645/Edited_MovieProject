export default function validateModifiers(modifiers: Array<any>): void;
