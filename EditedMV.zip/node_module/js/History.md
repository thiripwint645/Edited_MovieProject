
0.1.0 / 2013-04-24 
==================

  * Add silent flag.
  * Add ugly output mode.
  * Attempt to parse code both in expression and statement list contexts.
  * Use expression result as status.

0.0.1 / 2013-04-22
==================

  * Initial release.