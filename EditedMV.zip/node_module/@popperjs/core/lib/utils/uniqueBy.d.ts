export default function uniqueBy<T>(arr: Array<T>, fn: (arg0: T) => any): Array<T>;
